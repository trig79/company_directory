<?php
// for creation of json object to link with trent tree plugin. 
include(dirname(__DIR__).'/php/dbConnection.php');

ini_set('display_errors', 'On');
error_reporting(E_ALL);

$director1 = 'Director';
$snrMgr = 'Snrmanager';
$Mgr = 'manager';
$asso1 = 'associate1';
$asso2 = 'associate2';
$asso3 = 'associate3';

$json =[];

$associate = [];
$manager['children'] = [];
$seniormanger['children'] = [];
$director['children'] = [];

$temp = [];
$temp['text']['name'] = $snrMgr;

array_push($seniormanger, $temp);

//$temp = [];
$temp['text']['name'] = $asso1;
array_push($manager['children'], $temp);

$temp['text']['name'] = $asso2;
array_push($manager['children'], $temp);

$temp['text']['name'] = $asso3;
array_push($manager['children'], $temp);

//$temp = [];
$temp['text']['name'] = $Mgr;
array_push($seniormanger['children'], $temp);


//array_push($manager['children'], $associate);
array_push($seniormanger['children'], $manager);

//$seniormanger = array_values($seniormanger['children']);
//$manger = array_values($manager['children']);
//$associate = array_values($associate);




 echo json_encode($seniormanger);
//echo json_encode($b);

mysqli_close($conn);
