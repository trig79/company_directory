# company_directory

Scope
“Create a desktop website that can also run on a mobile that allows for the maintenance of a company personnel database to see who’s who, who reports to who and where they are”.

Frameworks/Plugins:

    2. Jquery    - imported via cdn.
    3. bootstrap - imported via cdn.

A CRUD application, that interacts with the DB via AJAX/PHP.
